var myApp = angular.module('myApp', []);

// handle form submission when the form is completely valid
myApp.controller("MainCtrl", function($scope,$http) {
  var url = "http://127.0.0.1:8000/api/";
  $scope.qty_limit_exceed = '';
  $scope.productRow=[];
  $scope.customerid='';
  $scope.cartproductid='';
  $http.get(url+'billnumber').then(function (response) {
      
      if(response.status==200)
      {
        $scope.billnumber = response.data.data;
      }   
  });


  $http.get(url+'products').then(function (response) {
      if(response.status==200)
      {
        $scope.products = response.data.data;
      } 
  });

  $scope.formSent = false;
  $scope.sendForm = function() {
    $scope.formSent = true;
    alert('form valid, sending request...');
  };

  $scope.selectProduct=function(product){
    if(product!=='')
    {
      $http.get(url+'quantity/'+product).then(function (response){ 
          if(response.status==200 && response!=undefined)
          {
            $scope.maxQuantity = response.data.data['quantity'];
            $scope.price = response.data.data['price'];
            $scope.product_name = response.data.data['product_name'];
          } 
          $scope.totalamount=$scope.price*$scope.quantity;
      });
    }
  };
  
  $scope.enterQuantity=function(qty){
      if(qty>$scope.maxQuantity)
      {
        $scope.qty_limit_exceed="Quantity Limit Exceed";
      }
      else
      {
        $scope.qty_limit_exceed=""; 
        $scope.totalamount=$scope.price* $scope.quantity;
      }
  };

  $scope.addProduct =function(){ 
    var products = {
      cartproductid:$scope.cartproductid,
      billnumber:$scope.billnumber,
      customername:$scope.customername,
      customer_id:$scope.customer_id,
      gender:$scope.gender,
      address:$scope.address,
      productid:$scope.productid,
      quantity:$scope.quantity,
      product_name:$scope.product_name,
      totalamount:$scope.totalamount,  
    };

    $http({
        method : "POST",
        url : url+'addproduct',
        headers: {'Content-Type': 'application/json','accept': 'application/json'},
        data:products
    }).then(function mySuccess(response) {
        var data = response.data.data;
        $scope.productRow.push(data);
        $scope.productid='';
        $scope.quantity='';
        $scope.price='';
        $scope.totalamount='';
        $scope.productRow.map(function(item,index){
          if($scope.cartproductid==item.id)
          {
            $scope.productRow.splice(index,1);
          }
        });
    },
    function myFailure(response)
    {
         // failure callback
    });
  };

  $scope.editProduct=function(product){ 

    $scope.productRow.map(function(item,index){
      if(item.id==product)
      {
        $scope.cartproductid = item.id
        $scope.productid=item.product_id;
        $scope.quantity=item.quantity;
        $scope.price=item.price;
        $scope.totalamount=item.price*item.quantity;
      }
    });
  };
});

// directive that prevents submit if there are still form errors
myApp.directive("validSubmit", [ "$parse", function($parse) {
    return {
      // we need a form controller to be on the same element as this directive
      // in other words: this directive can only be used on a <form>
      require: 'form',
      // one time action per form
      link: function(scope, element, iAttrs, form) {
        form.$submitted = false;
        // get a hold of the function that handles submission when form is valid
        var fn = $parse(iAttrs.validSubmit);

        // register DOM event handler and wire into Angular's lifecycle with scope.$apply
        element.on("submit", function(event) {
          scope.$apply(function() {
            // on submit event, set submitted to true (like the previous trick)
            form.$submitted = true;
            // if form is valid, execute the submission handler function and reset form submission state
            if (form.$valid) {
              fn(scope, { $event : event });
              form.$submitted = false;
            }
          });
        });
      }
    };
  }
]);