<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cart extends Model
{
    protected $table = 'product_cart';
    protected $fillable = [
        'customer_id', 'product_id','quantity','total_amount'
    ];
}
