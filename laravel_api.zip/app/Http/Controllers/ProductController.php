<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Product;
use App\Cart;
use App\User;

class ProductController extends Controller
{

	function __construct()
	{		
		$this->msg['message']='';
    	$this->msg['data']=null;
    	$http_code=200;
	}

	public function getProduct()
	{
		$product = Product::select('id','product_name')->get();
		
		if(!empty($product))
		{
			$this->msg['message']='Product sent successfully';
    		$this->msg['data']=$product;
    		$http_code=200;		
		}
		else
		{
			$this->msg['message']='No product available';
    		$this->msg['data']=(object)null;
    		$http_code=200;			
		}

	    return response()->json($this->msg,$http_code);
	}

	public function getBillNumber()
	{
		
		$id = Cart::select('id')->orderBy('id', 'DESC')->first();
		$this->msg['message']='Bill Number';
    	$this->msg['data']=$id['id'] + 1;
    	$http_code=200;

    	return response()->json($this->msg,$http_code);	
   	}
   	
   	public function getProductQuantity($product_id)
   	{
   		$quantity = Product::select('quantity','price','product_name')->where('id',$product_id)->first();
   		
   		$this->msg['message']='Quantity';
    	$this->msg['data']=$quantity;
    	$http_code=200;

    	return response()->json($this->msg,$http_code);	
   	}
   	
   	public function addProduct(Request $request)
   	{  		
   		if(!empty($request->all()))
   		{
   			//echo "<pre>";print_r($request->all());die;
	   		$gender = 0;
	   		$userid ='';
	   		if(!empty($request->gender['female']))
	   		{
	   			$gender = 0;
	   		}
	   		else
	   		{	
	   			$gender = 1;
	   		}
	   		if($request->customer_id=='')
	   		{
		   		$user = User::create([
		   			'customername'=>$request->customername,
		   			'address'=>$request->address,
		   			'gender'=>$gender
		   		]);
		   		$userid = $user->id;
	   		}
	   		else
	   		{
	   			$userid = $request->customer_id;	
	   		}
	   		
	   		if(!empty($user))
	   		{
	   			if($request->cartproductid=='')
	   			{
			   		$nextbill = Cart::create([
			   			'customer_id'=>$userid,
			   			'product_id'=>$request->productid,
			   			'quantity'=>$request->quantity,
			   			'total_amount'=>$request->totalamount
			   		]);
	   			}
	   			else
	   			{
	   				$nextbill =Cart::where('id',$request->cartproductid)->first();

	   				$nextbill->customer_id=$userid;
	   				$nextbill->product_id=$request->productid;
	   				$nextbill->quantity=$request->quantity;
	   				$nextbill->total_amount=$request->totalamount;
	   				$nextbill->save();
	   			}

		   		if(!empty($nextbill))
		   		{ 
		   			$product = Product::where('id',$nextbill->product_id)->first();
		   			$product->quantity = $product->quantity - $nextbill->quantity;
		   			$product->save();

		   			$nextbill['product_name'] = $product->product_name;
		   			$nextbill['price'] = $product->price;
		   			$this->msg['message']='Product Added Successfully';
	    			$this->msg['data']=$nextbill;
	    			$http_code=200;
		   		}
		   		else
		   		{
		   			$this->msg['message']='Product Added Successfully';
	    			$this->msg['data']=(object)null;
	    			$http_code=400;
		   		}
	   		}
	   		else
	   		{
	   			$this->msg['message']='Failed to create user';
				$this->msg['data']=(object)null;
				$http_code=400;
	   		}
	   		
	   		return response()->json($this->msg,$http_code);	
   		}
   	}
   		
}
