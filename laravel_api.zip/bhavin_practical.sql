-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 11, 2018 at 10:12 AM
-- Server version: 5.7.14
-- PHP Version: 7.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bhavin_practical`
--

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `product_name` varchar(255) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `product_name`, `quantity`, `price`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'A', 20, 100, NULL, '2018-08-11 04:35:32', NULL),
(2, 'B', 27, 200, NULL, '2018-08-11 04:36:48', NULL),
(3, 'C', 44, 300, NULL, '2018-08-11 04:33:53', NULL),
(4, 'D', 49, 400, NULL, '2018-08-11 04:36:58', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `product_cart`
--

CREATE TABLE `product_cart` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `total_amount` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_cart`
--

INSERT INTO `product_cart` (`id`, `customer_id`, `product_id`, `quantity`, `total_amount`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 59, 3, 4, NULL, '2018-08-11 04:32:57', '2018-08-11 04:33:53', NULL),
(2, 61, 2, 2, 400, '2018-08-11 04:35:32', '2018-08-11 04:35:43', NULL),
(3, 63, 4, 1, 400, '2018-08-11 04:36:48', '2018-08-11 04:36:58', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `customername` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` tinyint(4) DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `customername`, `email`, `gender`, `address`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, NULL, NULL, 1, NULL, NULL, NULL, '2018-08-11 03:22:30', '2018-08-11 03:22:30'),
(2, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 03:22:30', '2018-08-11 03:22:30'),
(3, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 03:24:06', '2018-08-11 03:24:06'),
(4, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 03:25:18', '2018-08-11 03:25:18'),
(5, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 03:29:30', '2018-08-11 03:29:30'),
(6, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 03:30:51', '2018-08-11 03:30:51'),
(7, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 03:31:17', '2018-08-11 03:31:17'),
(8, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 03:33:23', '2018-08-11 03:33:23'),
(9, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 03:35:17', '2018-08-11 03:35:17'),
(10, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 03:35:58', '2018-08-11 03:35:58'),
(11, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 03:36:29', '2018-08-11 03:36:29'),
(12, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 03:37:18', '2018-08-11 03:37:18'),
(13, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 03:49:23', '2018-08-11 03:49:23'),
(14, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 03:50:06', '2018-08-11 03:50:06'),
(15, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 03:51:10', '2018-08-11 03:51:10'),
(16, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 03:53:14', '2018-08-11 03:53:14'),
(17, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 03:53:15', '2018-08-11 03:53:15'),
(18, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 03:53:16', '2018-08-11 03:53:16'),
(19, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 03:53:30', '2018-08-11 03:53:30'),
(20, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 03:54:06', '2018-08-11 03:54:06'),
(21, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 03:54:44', '2018-08-11 03:54:44'),
(22, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 03:54:47', '2018-08-11 03:54:47'),
(23, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 03:55:01', '2018-08-11 03:55:01'),
(24, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 03:57:35', '2018-08-11 03:57:35'),
(25, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 03:58:21', '2018-08-11 03:58:21'),
(26, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 03:59:21', '2018-08-11 03:59:21'),
(27, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 04:00:21', '2018-08-11 04:00:21'),
(28, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 04:01:05', '2018-08-11 04:01:05'),
(29, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 04:01:15', '2018-08-11 04:01:15'),
(30, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 04:01:16', '2018-08-11 04:01:16'),
(31, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 04:03:22', '2018-08-11 04:03:22'),
(32, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 04:03:28', '2018-08-11 04:03:28'),
(33, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 04:04:00', '2018-08-11 04:04:00'),
(34, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 04:06:33', '2018-08-11 04:06:33'),
(35, 'TEST3', NULL, 1, 'dfgghfh', NULL, NULL, '2018-08-11 04:07:12', '2018-08-11 04:07:12'),
(36, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 04:07:52', '2018-08-11 04:07:52'),
(37, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 04:13:20', '2018-08-11 04:13:20'),
(38, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 04:14:08', '2018-08-11 04:14:08'),
(39, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 04:18:45', '2018-08-11 04:18:45'),
(40, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 04:18:54', '2018-08-11 04:18:54'),
(41, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 04:19:38', '2018-08-11 04:19:38'),
(42, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 04:20:09', '2018-08-11 04:20:09'),
(43, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 04:21:04', '2018-08-11 04:21:04'),
(44, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 04:21:07', '2018-08-11 04:21:07'),
(45, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 04:22:01', '2018-08-11 04:22:01'),
(46, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 04:22:10', '2018-08-11 04:22:10'),
(47, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 04:23:58', '2018-08-11 04:23:58'),
(48, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 04:24:23', '2018-08-11 04:24:23'),
(49, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 04:24:33', '2018-08-11 04:24:33'),
(50, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 04:26:06', '2018-08-11 04:26:06'),
(51, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 04:26:43', '2018-08-11 04:26:43'),
(52, 'TEST3', NULL, 1, 'dfgghfh', NULL, NULL, '2018-08-11 04:27:44', '2018-08-11 04:27:44'),
(53, 'TEST3', NULL, 1, 'dfgghfh', NULL, NULL, '2018-08-11 04:27:54', '2018-08-11 04:27:54'),
(54, 'TEST3', NULL, 1, 'dfgghfh', NULL, NULL, '2018-08-11 04:28:07', '2018-08-11 04:28:07'),
(55, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 04:29:52', '2018-08-11 04:29:52'),
(56, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 04:32:57', '2018-08-11 04:32:57'),
(57, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 04:33:04', '2018-08-11 04:33:04'),
(58, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 04:33:26', '2018-08-11 04:33:26'),
(59, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 04:33:53', '2018-08-11 04:33:53'),
(60, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 04:35:32', '2018-08-11 04:35:32'),
(61, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 04:35:43', '2018-08-11 04:35:43'),
(62, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 04:36:48', '2018-08-11 04:36:48'),
(63, 'Mehul Prajapati', NULL, 1, '5048 Tennyson Pkwy\ngdfgdg', NULL, NULL, '2018-08-11 04:36:58', '2018-08-11 04:36:58');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_cart`
--
ALTER TABLE `product_cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `product_cart`
--
ALTER TABLE `product_cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
